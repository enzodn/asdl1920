import pandas as pd


def creator_df(dataframe, series, string):
    d = pd.DataFrame(series)
    d.columns = [string]
    dataframe = pd.concat([dataframe, d], axis=1)
    return dataframe


evalfram = pd.read_csv('CSVData/evalfram.csv')

# rimuove l'ultima riga che conteneva valori NaN
evalfram = evalfram.iloc[:, 1:7]

# crea una lista contenente le sequenze
sequences = []
for i in range(50, 1550, 50):
    b = i*2
    a = b-100
    sequences.append(evalfram.iloc[a:b, :7])


min_df = pd.DataFrame()
max_df = pd.DataFrame()
mean_df = pd.DataFrame()
std_df = pd.DataFrame()

# crea dataframe per minimo, massimo, media, deviazione standard
i = 50
for seq in sequences:
    min_df = creator_df(min_df, seq.min(), str(i))
    max_df = creator_df(max_df, seq.max(), str(i))
    mean_df = creator_df(mean_df, seq.mean(), str(i))
    std_df = creator_df(std_df, seq.std(), str(i))
    i = i+50

min_df = min_df.transpose()
max_df = max_df.transpose()
mean_df = mean_df.transpose()
std_df = std_df.transpose()

# unisce tutti i dataframes e crea il file csv
result = pd.concat([min_df, max_df, mean_df, std_df], axis=1, sort=False)
result.to_csv('result.csv')
